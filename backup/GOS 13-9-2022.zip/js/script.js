$(".sidebar li a").on("click", function(){
    $(this).addClass(".sidebar li a");
});

function update(){
    alert("You are not allow to  edit this profile");
}